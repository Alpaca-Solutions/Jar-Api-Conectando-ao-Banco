package dados;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExecutarComSenha {
    public static void main(String[] args) {
        String senhaCorreta = "123";

        System.out.print("Digite a senha: ");
        String senhaDigitada = new java.util.Scanner(System.in).nextLine();

        if (senhaDigitada.equals(senhaCorreta)) {
            System.out.println("Senha correta. Executando o comando Java.");

            String diretorio = "C:\\Users\\annam\\OneDrive\\Área de Trabalho\\ALPACA- SPRINT 2\\Teste-Jar-Novo\\v2-jar-alpaca-solutions\\target";

            try {
                // Salve o diretório atual
                String diretorioAtual = System.getProperty("user.dir");

                // Mude para o diretório de destino
                System.setProperty("user.dir", diretorio);

                // Crie um ProcessBuilder
                ProcessBuilder builder = new ProcessBuilder("java", "-jar", diretorio + "\\v2-jar-alpaca-solutions-1.0-jar-with-dependencies.jar");

                builder.redirectErrorStream(true);

                // Inicie o processo
                Process processo = builder.start();

                // Capture a saída padrão e a saída de erro
                BufferedReader reader = new BufferedReader(new InputStreamReader(processo.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }

                // Aguarde o término do processo
                int status = processo.waitFor();

                // Restaure o diretório original
                System.setProperty("user.dir", diretorioAtual);

                if (status == 0) {
                    System.out.println("Comando executado com sucesso.");
                } else {
                    System.out.println("Erro ao executar o comando. Código de saída: " + status);
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Senha incorreta. A execução foi interrompida.");
        }
    }
}
