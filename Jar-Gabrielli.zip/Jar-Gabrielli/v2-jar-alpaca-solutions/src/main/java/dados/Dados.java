package dados;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.Disco;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.rede.RedeInterface;

import java.util.Scanner;

public class Dados {
    public static void main(String[] args) {
        Looca looca = new Looca();
        Scanner scanner = new Scanner(System.in);
        String opcao;

        do {
            System.out.println("Selecione uma opção de monitoramento:");
            System.out.println("1. Capacidade do disco rígido");
            System.out.println("2. Uso da memória");
            System.out.println("3. Uso da CPU");
            System.out.println("4. Dados de rede");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = scanner.nextLine();

            switch (opcao) {
                case "1":
                    mostrarCapacidadeDisco(looca);
                    break;
                case "2":
                    // Chamar método para mostrar o uso da memória
                    mostrarUsoDeMemoria(looca);
                    break;
                case "3":
                    // Chamar método para mostrar o uso da CPU
                    mostrarUsoDeCPU(looca);
                    break;
                case "4":
                    mostrarRede(looca);
                    break;
                case "0":
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (!opcao.equals("0"));
    }

    private static void mostrarCapacidadeDisco(Looca looca) {
        for (Disco disco : looca.getGrupoDeDiscos().getDiscos()) {
            System.out.println("Capacidade do disco rígido: " + disco.getTamanho());
        }
    }

    private static void mostrarUsoDeMemoria(Looca looca) {

        com.github.britooo.looca.api.group.memoria.Memoria memoria = new com.github.britooo.looca.api.group.memoria.Memoria();

        System.out.println("Informações de Memória");
        System.out.println(memoria);

    }

    private static void mostrarUsoDeCPU(Looca looca) {
        Processador processador = new Processador();

        System.out.println("Numeros de Cpus Lógicas" + processador.getNumeroCpusLogicas());
        System.out.println("Numeros de Cpus Físicas" + processador.getNumeroCpusFisicas());
    }
    private static void mostrarRede(Looca looca) {
        for (RedeInterface rede : looca.getRede().getGrupoDeInterfaces().getInterfaces()) {
            System.out.println("Rede : " + rede.getBytesRecebidos());
        }
    }

}