package dados;

import com.github.britooo.looca.api.group.rede.RedeParametros;
import oshi.SystemInfo;

import java.util.List;

public class Rede {

    private long quantidade_bytes_recebidos;

    private long quantidade_bytes_enviados;

    private String host_name;

    private List<String> servidor_dns;

    private String nome_dominio;

    public Rede(long quantidade_bytes_recebidos, long quantidade_bytes_enviados, String host_name, List<String> servidor_dns, String nome_dominio) {
        this.quantidade_bytes_recebidos = quantidade_bytes_recebidos;
        this.quantidade_bytes_enviados = quantidade_bytes_enviados;
        this.host_name = host_name;
        this.servidor_dns = servidor_dns;
        this.nome_dominio = nome_dominio;
    }

    public Rede() {

    }

    public long getQuantidade_bytes_recebidos() {
        return quantidade_bytes_recebidos;
    }

    public void setQuantidade_bytes_recebidos(long quantidade_bytes_recebidos) {
        this.quantidade_bytes_recebidos = quantidade_bytes_recebidos;
    }

    public long getQuantidade_bytes_enviados() {
        return quantidade_bytes_enviados;
    }

    public void setQuantidade_bytes_enviados(long quantidade_bytes_enviados) {
        this.quantidade_bytes_enviados = quantidade_bytes_enviados;
    }

    public String getHost_name() {
        return host_name;
    }

    public void setHost_name(String host_name) {
        this.host_name = host_name;
    }

    public List<String> getServidor_dns() {
        return servidor_dns;
    }

    public void setServidor_dns(List<String> servidor_dns) {
        this.servidor_dns = servidor_dns;
    }

    public String getNome_dominio() {
        return nome_dominio;
    }

    public void setNome_dominio(String nome_dominio) {
        this.nome_dominio = nome_dominio;
    }

    @Override
    public String toString() {
        return String.format("Dados de Rede\n" +
                "Quantidade de bytes recebidos:%d bytes\n" +
                "Quantidade de bytes enviados:%d bytes\n" +
                "Nome do Host: %s\n" +
                "Servidor DNS: %s\n" +
                "Nome do domínio: %s\n", quantidade_bytes_recebidos, quantidade_bytes_enviados, host_name, servidor_dns, nome_dominio);
    }
}
