import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.janelas.Janela;
import com.github.britooo.looca.api.group.janelas.JanelaGrupo;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.sistema.Sistema;
import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.DecimalFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.Duration;


public class Dados {
    public static void main(String[] args) {
        Conexao conexao = new Conexao();
        JdbcTemplate con = conexao.getConexaoDoBanco();
        Scanner scanner = new Scanner(System.in);
        String continuar;

        con.update("create table IF NOT EXISTS sistema_informacoes (\n" +
                "id int primary key auto_increment,\n" +
                "nome_do_sistema varchar(255),\n" +
                "tempo_atividade VARCHAR(255),\n" +
                "quantidade_abas_abertas int,\n" +
                "porcentagem_uso_cpu int," +
                "porcentagem_uso_memoria int" +
                ");");

        do {
            Looca looca = new Looca();
            Sistema sistema = looca.getSistema();
            Processador processador = looca.getProcessador();
            Memoria memoria = looca.getMemoria();
            JanelaGrupo janelaGrupo = looca.getGrupoDeJanelas();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")
                    .withZone(ZoneId.systemDefault());

            // Obtém a data e hora atual
            Instant now = Instant.now();
            // Calcula a diferença entre a data atual e a data de inicialização
            Duration tempoAtividade = Duration.between(sistema.getInicializado(), now);
            // Formata a diferença para exibição amigável
            long dias = tempoAtividade.toDays();
            long horas = tempoAtividade.toHours() % 24;
            long minutos = tempoAtividade.toMinutes() % 60;
            long segundos = tempoAtividade.getSeconds() % 60;

            String tempoAtividadeFormatado = String.format("%d days, %02d:%02d:%02d", dias, horas, minutos, segundos);
            String nomeSistema = sistema.getSistemaOperacional();

            //Obter a qtdJanelas abertas
            List <Janela> listaJanelas = janelaGrupo.getJanelasVisiveis();
            int qtdjanelasAbertas = 0;
            for (int i = 0; i < listaJanelas.size(); i++){
                if (!listaJanelas.get(i).getTitulo().isEmpty()) {
                    listaJanelas.get(i);
                    qtdjanelasAbertas += 1;
                }
            }



            BigDecimal porcentagemUsoCpu = BigDecimal.valueOf(processador.getUso()).setScale(2, RoundingMode.HALF_UP);
            BigDecimal porcentagemUsoMemoria = BigDecimal.valueOf((double) memoria.getEmUso() / memoria.getTotal() * 100).setScale(2, RoundingMode.HALF_UP);
            //tirar a parte inteira da CPU E memoria
            DecimalFormat formato = new DecimalFormat("#");

            System.out.println("""
                    *---------------------------------------------------*
                    *    Bem Vindo! A Alpaca Solutions                  *       
                    *---------------------------------------------------*
                    *       MONITORANDO SUA MAQUINA...                  
                    *                                                   
                    * Sistema Operacional: %s     
                    * Tempo de Atividade: %s                          
                    * Quantidade de Abas Abertas: %d                  
                    * Uso da CPU: %s%%                                   
                    * Uso de Memoria: %s%%                               
                    *---------------------------------------------------*
                    """.formatted(nomeSistema,tempoAtividadeFormatado,qtdjanelasAbertas,formato.format(porcentagemUsoCpu),formato.format(porcentagemUsoMemoria)));

            System.out.println("Deseja continuar inserindo dados? Digite '1' para continuar ou qualquer outra tecla para sair: ");
            continuar = scanner.nextLine();

            if (!"1".equals(continuar)) {
                break;
            }

            // Inserir os dados no banco de dados
            con.update("insert into sistema_informacoes (nome_do_sistema, tempo_atividade, quantidade_abas_abertas, porcentagem_uso_cpu, porcentagem_uso_memoria) values (?, ?, ?, ?, ?);",
                    nomeSistema, tempoAtividadeFormatado, qtdjanelasAbertas, porcentagemUsoCpu, porcentagemUsoMemoria);

            System.out.println("Dados inseridos com sucesso!");

        } while (true);
    }
}
