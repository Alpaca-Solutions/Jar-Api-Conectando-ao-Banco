package dados;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.Disco;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.rede.RedeInterface;
import dados.Cliente;
import dados.Conexao;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Scanner;

public class Dados {
    public static void main(String[] args) {
        Conexao conexao = new Conexao();
        Looca looca = new Looca();
        JdbcTemplate con = conexao.getConexaoDoBanco();
        Scanner leitor = new Scanner(System.in);
        Cliente cliente = new Cliente();
        String email = "";
        String senha = "";
        Integer opcao = 0;
        double tamanhoTotalGiB = 0;
        Double tot_disco = 0.0;
        Integer total_disco = 0;
        Double tamanho_disco = 0.0;

        con.update("create table IF NOT EXISTS cadastro(" +
                "id int primary key auto_increment," +
                "email varchar(50)," +
                "senha varchar(50) )");

        String email_01 = "ewerton@gmail.com";
        String senha_01 = "12345678";
        con.update("insert into cadastro (email, senha) values (?, ?)", email_01, senha_01);

        con.update("create table IF NOT EXISTS cpu (" +
                "porcentagem_uso_cpu decimal , " +
                "qtd_nucleos decimal)");

        con.update("create table IF NOT EXISTS memoria(" +
                "idmemoria int primary key auto_increment ," +
                "porcentagem_uso_memoria decimal ," +
                "qtd_memoria_disponivel decimal , " +
                "tamanho_memoria decimal , " +
                "quantidade_de_ram decimal)");

        con.update("create table IF NOT EXISTS disco(" +
                "iddisco int primary key auto_increment ," +
                "Tamanho_Total_do_Disco decimal)");

        con.update("create table IF NOT EXISTS rede(" +
                "idrede int primary key auto_increment," +
                "bytes_recebidos decimal, " +
                "bytes_enviados decimal, " +
                "pacotes_recebidos decimal, " +
                "pacotes_enviados decimal)");


        System.out.println("Bem vindo ao sistema de monitoramento de servidores educacionais alpaca solutions \uD83D\uDE00");


            System.out.println("Digite seu email:");
            email = leitor.nextLine();
            cliente.setEmail(email);

            System.out.println("Digite sua senha agora:");
            senha = leitor.nextLine();
            cliente.setSenha(senha);

            String sql = "SELECT * FROM cadastro WHERE email = ? AND senha = ?";

            try {
                List<Cliente> listaCliente = con.query(sql, new Object[]{cliente.getEmail(), cliente.getSenha()}, new BeanPropertyRowMapper<>(Cliente.class));

                if (listaCliente.isEmpty()) {
                    System.out.println("Não existe cadastro em nossa base de dados, faça o cadastro e tente novamente \uD83D\uDE41");
                } else {

                    do {
                        System.out.println("+------------------------------------------------------------+\n" +
                                "Verifiquei que você tem cadastro, o que você quer visualizar \uD83D\uDE01" +
                                "\n1-)Dados Da CPU\n" +
                                "2-)Dados da Memória\n" +
                                "3-)Dados do Disco\n" +
                                "4-)Dados da Rede:\n" +
                                "5-)Sair\n" +
                                "+------------------------------------------------------------+");
                        opcao = leitor.nextInt();

                        switch (opcao) {
                            case 1: {
                                Processador processador = new Processador();
                                long qtd_nucleos_cpu = processador.getNumeroCpusFisicas() + processador.getNumeroCpusLogicas();

                                CPU cpu = new CPU(processador.getUso() , qtd_nucleos_cpu);

                                System.out.println(cpu);

                                con.update("insert into cpu values (? , ?)" , cpu.getUso_da_cpu() , cpu.getQtd_nucleos());
                                break;
                            }
                            case 2: {
                                Memoria memoria = new Memoria();
                                Double percentual_memoria_disponivel = (double) memoria.getEmUso() / memoria.getTotal() * 100;
                                Double ramDisponivel = (double) memoria.getDisponivel() / (1024 * 1024 * 1024);
                                dados.Memoria dados_memoria = new dados.Memoria(percentual_memoria_disponivel , memoria.getDisponivel() ,
                                        memoria.getTotal()  , ramDisponivel);
                                System.out.println(dados_memoria);
                                    con.update("insert into memoria (porcentagem_uso_memoria ,qtd_memoria_disponivel," +
                                        " tamanho_memoria , quantidade_de_ram) values (?, ? , ? , ?)", dados_memoria.getPorcentagem_uso_memoria(),
                                        dados_memoria.getQtd_memoria_disponivel() ,dados_memoria.getTamanho_memoria() , dados_memoria.getQuantidade_de_ram());
                                break;
                            }
                                case 3: {

                                    Double tamanho_do_disco = 0.0;
                                    for (Disco disco : looca.getGrupoDeDiscos().getDiscos()) {
                                        tamanho_do_disco = Double.valueOf(disco.getTamanho());
                                    }
                                    dados.Disco disco01 = new dados.Disco(tamanho_do_disco);

                                    System.out.println(disco01);
                                    con.update("insert into disco (Tamanho_Total_do_Disco) values(?)", disco01.getTamanho_do_disco());
                                    break;
                                }




                            case 4:{

                                List<RedeInterface> dados_de_rede = looca.getRede().getGrupoDeInterfaces().getInterfaces();
                                RedeInterface adaptador_com_dados = null;
                                long maiorBytesrecebidos = 0;
                                long total_bytes_recebidos = 0;
                                long total_bytes_enviados = 0;

                                // Coleta informações de rede
                                for (RedeInterface interfaceRede : dados_de_rede) {
                                    long bytes_recebidos = interfaceRede.getBytesRecebidos();
                                    if (bytes_recebidos > maiorBytesrecebidos) {
                                        adaptador_com_dados = interfaceRede;
                                        maiorBytesrecebidos = bytes_recebidos;
                                    }
                                }

                                dados.Rede rede01 = new Rede(adaptador_com_dados.getBytesRecebidos() , adaptador_com_dados.getBytesEnviados() , adaptador_com_dados.getPacotesEnviados(), adaptador_com_dados.getBytesEnviados());

                                System.out.println(rede01);
                                con.update("insert into rede (bytes_recebidos, bytes_enviados, pacotes_recebidos, pacotes_enviados) values (?, ?, ?, ?)",
                                        adaptador_com_dados.getBytesRecebidos(),
                                        adaptador_com_dados.getBytesEnviados(),
                                        adaptador_com_dados.getPacotesRecebidos(),
                                        adaptador_com_dados.getPacotesEnviados());

                                break;
                            }
                            case 5:{
                                System.out.println("Saindo.. foi um prazer atender os seus serviços \uD83D\uDC4B");
                                break;
                            }
                        }
                    } while (!opcao.equals(5));
                }
            } catch (Exception erro) {
                erro.printStackTrace();
            }

        }

        }

