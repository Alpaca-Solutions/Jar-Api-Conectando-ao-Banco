package dados;

import java.math.BigDecimal;

public class Memoria {

    private Double porcentagem_uso_memoria;

    private long qtd_memoria_disponivel;

    private long tamanho_memoria;

    private Double quantidade_de_ram;

    public Memoria(Double porcentagem_uso_memoria, long qtd_memoria_disponivel, long tamanho_memoria, Double quantidade_de_ram) {
        this.porcentagem_uso_memoria = porcentagem_uso_memoria;
        this.qtd_memoria_disponivel = qtd_memoria_disponivel;
        this.tamanho_memoria = tamanho_memoria;
        this.quantidade_de_ram = quantidade_de_ram;
    }

    public Double getPorcentagem_uso_memoria() {
        return porcentagem_uso_memoria;
    }

    public void setPorcentagem_uso_memoria(Double porcentagem_uso_memoria) {
        this.porcentagem_uso_memoria = porcentagem_uso_memoria;
    }

    public long getQtd_memoria_disponivel() {
        return qtd_memoria_disponivel;
    }

    public void setQtd_memoria_disponivel(long qtd_memoria_disponivel) {
        this.qtd_memoria_disponivel = qtd_memoria_disponivel;
    }

    public long getTamanho_memoria() {
        return tamanho_memoria;
    }

    public void setTamanho_memoria(long tamanho_memoria) {
        this.tamanho_memoria = tamanho_memoria;
    }

    public Double getQuantidade_de_ram() {
        return quantidade_de_ram;
    }

    public void setQuantidade_de_ram(Double quantidade_de_ram) {
        this.quantidade_de_ram = quantidade_de_ram;
    }

    public String toString() {
        BigDecimal porcentagem_uso_da_memoria_arrendodada = BigDecimal.valueOf(porcentagem_uso_memoria).setScale(2, BigDecimal.ROUND_HALF_UP);
        BigDecimal memoriaDisponivelGB_arrendodada = BigDecimal.valueOf(qtd_memoria_disponivel).divide(BigDecimal.valueOf(1e9), 2, BigDecimal.ROUND_HALF_UP);
        BigDecimal tamanhoMemoriaGB_arrendodada = BigDecimal.valueOf(tamanho_memoria).divide(BigDecimal.valueOf(1e9), 2, BigDecimal.ROUND_HALF_UP);
        BigDecimal quantidadeDeRAMGB_arrendodada = BigDecimal.valueOf(quantidade_de_ram).setScale(2, BigDecimal.ROUND_HALF_UP);

        return String.format("Dados da Memoria\n" +
                        "Porcentagem de uso da memoria: %.2f%%\n" +
                        "Quantidade de memoria Disponivel: %s GB\n" +
                        "Tamanho da Memoria: %s GB\n" +
                        "Quantidade de ram: %.2f GB\n",
                porcentagem_uso_da_memoria_arrendodada, memoriaDisponivelGB_arrendodada, tamanhoMemoriaGB_arrendodada, quantidadeDeRAMGB_arrendodada);
    }



}
