package dados;

public class Disco {
    private Double tamanho_do_disco;


    public Disco(Double tamanho_do_disco) {
        this.tamanho_do_disco = tamanho_do_disco;
    }

    public Double getTamanho_do_disco() {
        return tamanho_do_disco;
    }

    public void setTamanho_do_disco(Double tamanho_do_disco) {
        this.tamanho_do_disco = tamanho_do_disco;
    }

    @Override
    public String toString() {
        return String.format("Dados do Disco\n" +
                        "Tamanho Total do Disco: %.1f GB\n",
                getTamanho_do_disco());
    }


}
